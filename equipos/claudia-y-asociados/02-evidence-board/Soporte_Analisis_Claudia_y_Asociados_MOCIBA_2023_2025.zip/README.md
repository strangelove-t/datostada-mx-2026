# Soporte verificable · Evidence Board · Claudia y Asociados

## Proyecto

Reto **Yucatán Digital · Detrás de la pantalla**. MOCIBA 2023, 2024 y 2025 del INEGI. Se estudia la prevalencia de al menos una situación de ciberacoso entre personas usuarias de internet de 12 años o más que residen en **Yucatán (CVE_ENT = 31)**, así como las diferencias descriptivas por sexo y tipo.

## Contenido

- `datos_originales/`: tres ZIP oficiales recibidos con `MOCIBA2023.csv`, `MOCIBA2024.csv`, `MOCIBA2025.csv`, y sus descriptores de variables `.xlsx`.
- `analisis_mociba.py`: código reproducible que ejecuta los cálculos y las comprobaciones de calidad.
- `resultados/indicadores_prevalencia.csv`: prevalencias ponderadas, por año y sexo (denominador: todas las personas usuarias de internet del grupo).
- `resultados/indicadores_situaciones.csv`: porcentajes por tipo sobre personas usuarias y sobre víctimas, por año y sexo (denominadores separados).
- `resultados/auditoria_calidad.csv`: número de registros, códigos faltantes y validaciones.
- `resultados/mociba_yucatan_2023_2025_tableau.csv`: registros anonimizados recortados a Yucatán con variables armonizadas para Tableau.
- `resultados/resumen_resultados.json`: resumen del método y resultados.
- `figuras/`: tres gráficos reproducibles empleados en el PDF.

## Cómo volver a ejecutar el análisis

Con Python 3.10+ instalado, desde la carpeta que contiene este README:

```bash
python -m pip install pandas numpy matplotlib
python analisis_mociba.py
```

El script descomprime los CSV directamente desde sus ZIP, filtra Yucatán y regenera los archivos en `resultados/` y `figuras/`.

## Cálculo

- `CVE_ENT = 31` corresponde a Yucatán; `SEXO = 1` hombres, `SEXO = 2` mujeres.
- El descriptor oficial define `P4_01` a `P4_13` con códigos: `1 = Sí`, `2 = No`, `9 = No sabe / no responde`.
- `victima = 1` cuando al menos una P4 es `1`.
- Prevalencia = 100 × suma de `FACTOR` entre víctimas ÷ suma de `FACTOR` de toda la población incluida en ese grupo y año.
- Frecuencia relativa de cada tipo entre víctimas = 100 × suma de `FACTOR` de víctimas con `P4_x = 1` ÷ suma de `FACTOR` de todas las víctimas de ese grupo y año.
- Una persona puede tener varias P4 afirmativas; por lo tanto los porcentajes de los distintos tipos **no suman 100 %**.
- El código `9` se deja como faltante en la tabla para Tableau, sin convertirlo en respuesta negativa.
- Las comparaciones de los tres años son descriptivas y de muestras independientes; el script **no** calcula errores estándar, intervalos de confianza ni pruebas con el diseño complejo. No se hacen inferencias causales.

## Recuento y controles

| Año | Registros de Yucatán | Prevalencia ponderada |
|---|---:|---:|
| 2023 | 1,408 | 20.7 % |
| 2024 | 1,341 | 29.7 % |
| 2025 | 1,378 | 18.6 % |

Los tres indicadores reproducen, redondeados a una decimal, los resultados estatales que publica el INEGI.

## Fuentes oficiales

- INEGI, MOCIBA 2023, 2024 y 2025: CSV y descriptores proporcionados por el equipo.
- [INEGI · Resultados MOCIBA 2024](https://www.inegi.org.mx/contenidos/programas/mociba/2024/doc/mociba2024_resultados.pdf) (cuadro de Yucatán, página 16).
- [INEGI · Programa MOCIBA 2025](https://www.inegi.org.mx/programas/mociba/2025/default.html).

## Transparencia

ChatGPT ayudó con el procesamiento programático, la estructura del reporte y la redacción. Todos los indicadores se calculan sobre los microdatos del INEGI usando el código adjunto; no se usaron datos sintéticos.
