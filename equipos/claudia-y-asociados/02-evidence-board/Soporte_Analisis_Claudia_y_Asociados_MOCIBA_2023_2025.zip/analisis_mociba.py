"""Análisis descriptivo verificable MOCIBA 2023-2025, Yucatán (CVE_ENT 31).

Entradas: datos_originales/mocibaYYYY_bd_csv.zip descargados del INEGI.
Salidas: resultados/*.csv, resultados/resumen_resultados.json y figuras/*.png.
Uso: python analisis_mociba.py
Dependencias: pandas, numpy, matplotlib.
"""
from pathlib import Path
import json
import zipfile
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

ROOT = Path(__file__).resolve().parent
DATOS = ROOT / 'datos_originales'
RESULT = ROOT / 'resultados'
FIGS = ROOT / 'figuras'
RESULT.mkdir(parents=True, exist_ok=True)
FIGS.mkdir(parents=True, exist_ok=True)
SITUACIONES = {
    'P4_01':'Mensajes ofensivos',
    'P4_02':'Llamadas ofensivas',
    'P4_03':'Críticas por apariencia o clase social',
    'P4_04':'Suplantación de identidad',
    'P4_05':'Contacto con identidades falsas',
    'P4_06':'Vigilancia de cuentas',
    'P4_07':'Provocaciones en línea',
    'P4_08':'Insinuaciones sexuales',
    'P4_09':'Fotos o videos sexuales no solicitados',
    'P4_10':'Difusión de contenido íntimo sin consentimiento',
    'P4_11':'Difusión de información personal para dañar',
    'P4_12':'Amenaza de difusión para extorsionar',
    'P4_13':'Otra situación',
}
VARS = ['CVE_ENT','NOM_ENT','SEXO','EDAD','FACTOR'] + list(SITUACIONES)


def ratio(numerador, denominador):
    return 100.0 * numerador / denominador if denominador > 0 else float('nan')


def weighted_group(df, year, sex):
    w = df['factor'].astype(float)
    victim = df['victima'].eq(1)
    total_w = float(w.sum())
    victim_w = float(w[victim].sum())
    return {'anio': year, 'sexo': sex, 'n_muestra': int(len(df)),
            'n_muestra_victimas': int(victim.sum()),
            'personas_expandidas': round(total_w, 3),
            'victimas_expandidas': round(victim_w, 3),
            'prevalencia_pct': round(ratio(victim_w,total_w), 6)}


def main():
    datasets = []
    quality, prevalence, types = [], [], []
    for year in (2023, 2024, 2025):
        zip_path = DATOS / f'mociba{year}_bd_csv.zip'
        with zipfile.ZipFile(zip_path) as z:
            names = [name for name in z.namelist() if name.lower().endswith('.csv')]
            assert len(names) == 1, f'{year}: no hay exactamente un CSV en ZIP'
            with z.open(names[0]) as fh:
                raw = pd.read_csv(fh, dtype=str, usecols=VARS, low_memory=False)
        n_nacional = len(raw)
        d = raw.loc[raw['CVE_ENT'].str.zfill(2).eq('31')].copy()
        assert len(d) > 0, f'{year}: recorte de Yucatán vacío'
        factor = pd.to_numeric(d['FACTOR'], errors='coerce')
        age = pd.to_numeric(d['EDAD'], errors='coerce')
        assert factor.notna().all() and factor.gt(0).all(), f'{year}: factor no válido'
        assert d['SEXO'].isin(['1','2']).all(), f'{year}: sexo fuera de catálogo'
        assert age.ge(12).all(), f'{year}: hay edades fuera de la población objetivo'
        values = d[list(SITUACIONES)]
        # 1 = sí, 2 = no, 9 = no sabe/no responde, según descriptores INEGI.
        unexpected = sorted(set(values.fillna('').to_numpy().ravel()) - {'1','2','9',''})
        assert not unexpected, f'{year}: códigos P4 inesperados: {unexpected}'
        eligible = values.eq('1').any(axis=1)
        no_information = ~values.isin(['1','2']).any(axis=1)
        assert not no_information.any(), f'{year}: sin información P4 para algunos registros'
        out = pd.DataFrame({
            'anio': year,
            'sexo': d['SEXO'].map({'1':'Hombres','2':'Mujeres'}),
            'edad': age.astype(int),
            'factor': factor.astype(float),
            'victima': eligible.astype(int),
        }, index=d.index)
        for var in SITUACIONES:
            # 9 = dato faltante para esa situación, no equivale a 'no'.
            out[var] = values[var].map({'1':1, '2':0, '9':np.nan}).astype(float)
        datasets.append(out.reset_index(drop=True))
        quality.append({
            'anio': year,
            'registros_nacionales': n_nacional,
            'registros_yucatan': len(d),
            'mujeres_muestra': int(d['SEXO'].eq('2').sum()),
            'hombres_muestra': int(d['SEXO'].eq('1').sum()),
            'factores_invalidos': int(factor.isna().sum() + factor.le(0).sum()),
            'edad_invalida': int((~age.ge(12)).sum()),
            'codigos_9_en_p4': int(values.eq('9').sum().sum()),
            'celdas_p4_vacias': int(values.isna().sum().sum()),
            'sin_respuesta_util_p4': int(no_information.sum()),
            'n_victimas_muestra': int(eligible.sum()),
        })
        for sex, g in [('Total',out),('Mujeres',out.loc[out.sexo.eq('Mujeres')]),('Hombres',out.loc[out.sexo.eq('Hombres')])]:
            prevalence.append(weighted_group(g,year,sex))
            overall_weight = float(g.factor.sum())
            victim_weight = float(g.loc[g.victima.eq(1),'factor'].sum())
            for variable,label in SITUACIONES.items():
                mask = g[variable].eq(1)
                selected_weight = float(g.loc[mask,'factor'].sum())
                types.append({'anio':year,'sexo':sex,'variable':variable,'situacion':label,
                              'n_muestra_si':int(mask.sum()),
                              'estimacion_ponderada_si':round(selected_weight,3),
                              'pct_de_usuarios_internet':round(ratio(selected_weight,overall_weight),6),
                              'pct_entre_victimas':round(ratio(selected_weight,victim_weight),6)})

    all_data = pd.concat(datasets,ignore_index=True)
    dfp = pd.DataFrame(prevalence)
    dft = pd.DataFrame(types)
    dfq = pd.DataFrame(quality)
    all_data.to_csv(RESULT/'mociba_yucatan_2023_2025_tableau.csv',index=False,encoding='utf-8-sig')
    dfp.to_csv(RESULT/'indicadores_prevalencia.csv',index=False,encoding='utf-8-sig')
    dft.to_csv(RESULT/'indicadores_situaciones.csv',index=False,encoding='utf-8-sig')
    dfq.to_csv(RESULT/'auditoria_calidad.csv',index=False,encoding='utf-8-sig')
    summaries={'fuente':'INEGI MOCIBA (archivos CSV 2023, 2024 y 2025)',
               'corte':'CVE_ENT = 31, Yucatán',
               'objetivo':'personas de 12 años o más usuarias de internet',
               'ponderador':'FACTOR',
               'indicador':'al menos una de P4_01..P4_13 = 1',
               'unidad':'porcentaje de personas usuarias de internet de 12+ para prevalencia',
               'calidad':quality,
               'prevalencia':[v for v in prevalence if v['sexo']=='Total'],
               'cambios_puntos_porcentuales':{
                    '2023_2024':round(float(dfp.loc[(dfp.anio==2024)&(dfp.sexo=='Total'),'prevalencia_pct'].iloc[0] - dfp.loc[(dfp.anio==2023)&(dfp.sexo=='Total'),'prevalencia_pct'].iloc[0]),6),
                    '2024_2025':round(float(dfp.loc[(dfp.anio==2025)&(dfp.sexo=='Total'),'prevalencia_pct'].iloc[0] - dfp.loc[(dfp.anio==2024)&(dfp.sexo=='Total'),'prevalencia_pct'].iloc[0]),6)
               }}
    (RESULT/'resumen_resultados.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2),encoding='utf-8')

    COLOR_DARK='#25354E'; COLOR_A='#71465A'; COLOR_B='#1F7D82'; COLOR_C='#E49B69'
    plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':10, 'axes.spines.top':False, 'axes.spines.right':False})
    overall = dfp.loc[dfp.sexo.eq('Total')].sort_values('anio')
    fig,ax=plt.subplots(figsize=(8.4,3.2))
    xx=overall.anio.to_numpy()
    yy=overall.prevalencia_pct.to_numpy()
    ax.plot(xx,yy, color=COLOR_A,linewidth=3, marker='o',markersize=11)
    ax.fill_between(xx,yy,alpha=.08,color=COLOR_A)
    for x,y in zip(xx,yy):ax.annotate(f'{y:.1f}%',(x,y),xytext=(0,12),textcoords='offset points',ha='center',fontweight='bold',fontsize=12,color=COLOR_DARK)
    ax.set_xticks(xx);ax.set_ylim(0,35);ax.set_yticks([0,10,20,30]);ax.yaxis.set_major_formatter(PercentFormatter(xmax=100,decimals=0))
    ax.grid(axis='y',alpha=.18);ax.set_ylabel('% de personas usuarias de internet (12+)')
    fig.tight_layout(pad=1.2);fig.savefig(FIGS/'01_prevalencia.png',dpi=180,transparent=False);plt.close(fig)

    split = dfp.loc[dfp.sexo.ne('Total')].pivot(index='anio',columns='sexo',values='prevalencia_pct').loc[[2023,2024,2025]]
    fig,ax=plt.subplots(figsize=(8.4,3.2))
    xs=np.arange(3); width=.34
    for offset,sex,color in [(-width/2,'Mujeres',COLOR_A),(width/2,'Hombres',COLOR_B)]:
        rect=ax.bar(xs+offset,split[sex].to_numpy(),width,color=color,label=sex)
        ax.bar_label(rect,fmt='%.1f%%',padding=3,fontsize=9)
    ax.set_xticks(xs,list(split.index));ax.set_ylim(0,38);ax.set_ylabel('% de cada sexo usuario de internet (12+)')
    ax.legend(frameon=False,ncol=2,loc='upper left');ax.grid(axis='y',alpha=.16);ax.set_axisbelow(True)
    fig.tight_layout(pad=1.1);fig.savefig(FIGS/'02_sexo.png',dpi=180);plt.close(fig)

    wanted = ['P4_05','P4_01','P4_04','P4_09','P4_08']
    heat = dft.loc[(dft.sexo=='Total') & dft.variable.isin(wanted)].pivot(index='variable',columns='anio',values='pct_entre_victimas').loc[wanted,[2023,2024,2025]]
    fig,ax=plt.subplots(figsize=(8.4,3.3))
    im=ax.imshow(heat.to_numpy(),cmap='PuBuGn',vmin=0,vmax=45,aspect='auto')
    ax.set_xticks(range(3),['2023','2024','2025']);ax.set_yticks(range(len(wanted)), [SITUACIONES[s] for s in wanted]);ax.tick_params(length=0,labelsize=9)
    for (i,j),val in np.ndenumerate(heat.to_numpy()):ax.text(j,i,f'{val:.1f}%',ha='center',va='center',color=('white' if val>28 else COLOR_DARK),fontweight='bold',fontsize=10)
    ax.set_xlim(-.5,2.5)
    fig.subplots_adjust(left=.39,right=.99,top=.99,bottom=.07)
    fig.savefig(FIGS/'03_situaciones.png',dpi=180);plt.close(fig)

    for row in overall.itertuples():
        print(f'{row.anio}: n={row.n_muestra}, prevalencia={row.prevalencia_pct:.4f}%, expandidos={row.personas_expandidas:,.0f}')
    print('OK: archivos generados en resultados/ y figuras/')

if __name__ == '__main__':
    main()
